#ifndef TestClass1_h
#define TestClass1_h
class TestClass1
{
  public:
    int myMethod(void);
};
#endif