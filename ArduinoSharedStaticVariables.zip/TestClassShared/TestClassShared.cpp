#include "TestClassShared.h"
float TestClassShared::mySharedPI = 3.14159;
int   TestClassShared::mySharedVariable = 5;
short TestClassShared::mySharedLength = MY_MESSAGE_BUFFER_LENGTH;
char  TestClassShared::mySharedBuffer[];
