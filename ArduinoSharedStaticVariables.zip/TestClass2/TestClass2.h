#ifndef TestClass2_h
#define TestClass2_h
class TestClass2
{
  public:
    int myMethod(void);
};
#endif